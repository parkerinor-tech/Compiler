#include "cSymbol.h"

// Define the static member
//long long cSymbol::nextId = 0;

